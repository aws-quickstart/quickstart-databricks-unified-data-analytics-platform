# importing the requests library 
import requests 
from requests.exceptions import HTTPError


def handler(event, context):
    message = 'Hello {} {} {}'.format(event['accountId'],
                                     event['role_arn'],
                                     event['credentials_name'])
    
    # Preparing query parameters for GET request
    
    # api-endpoint 
    GET_URL = "https://postman-echo.com/get?foo1=bar1&foo2=bar2"
    
    # location given here 
    location = "delhi technological university"
    
    # defining a params dict for the parameters to be sent to the API 
    PARAMS = {'address':location} 

    get_result = get_request(GET_URL, PARAMS)
    
    # Preparing json data for POST request
    
    # api-endpoint
    POST_URL = "https://postman-echo.com/post"
    
    # json data
    DATA = {
        "credentials_name": "pp_qstart_automation_credentials", 
        "aws_credentials": {
            "sts_role": {
                "role_arn": "arn:aws:iam::997819012307:role/denis_mws_qs_iam_role"
            }
        }
    }
    
    post_result = post_request(POST_URL, DATA)
    
    return {
        'get-result': get_result,
        'post-result': post_result
    }

# POST request function
def post_request(url, json_data):
    try:
        # sending post request and saving the response as response object
        resp = requests.post(url, json=json_data)
        
        # extracting data in json format 
        data = resp.json() 
        
        # If the response was successful, no Exception will be raised
        resp.raise_for_status()

        return {
            'data': data
        }
    except HTTPError as http_err:
        print(f'HTTP error occurred: {http_err}')
    except Exception as err:
        print(f'Other error occurred: {err}')

# GET request function
def get_request(url, params):
    try:
        # sending get request and saving the response as response object 
        resp = requests.get(url = url, params = params) 
        
        # extracting data in json format 
        data = resp.json() 
        
        # If the response was successful, no Exception will be raised
        resp.raise_for_status()
        
        return {
            'data': data
        }
    except HTTPError as http_err:
        print(f'HTTP error occurred: {http_err}')
    except Exception as err:
        print(f'Other error occurred: {err}')